<?php

class Invoice_Model_Purchase extends Core_Model_Item_Abstract
{
    protected $_route = 'invoice_general';
  
}
?>