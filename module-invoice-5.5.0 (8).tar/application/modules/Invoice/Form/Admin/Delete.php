<?php

class Demo_Form_Admin_Delete extends Engine_Form
{
  
}
?>