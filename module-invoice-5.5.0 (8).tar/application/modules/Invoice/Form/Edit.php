<?php

class Invoice_Form_Edit extends Engine_Form
{
    // public $_error = array();

    // protected $_parent_type;

    // protected $_parent_id;

    // public function setParent_type($value)
    // {
    //     $this->_parent_type = $value;
    // }

    // public function setParent_id($value)
    // {
    //     $this->_parent_id = $value;
    // }

    public function init()
    {
        $this->setTitle('Edit Invoice')
            ->setDescription('Edit the invoice below, then click "Edit".')
            ->setAttrib('name', 'Invoice_create');
        $user = Engine_Api::_()->user()->getViewer();
        $userLevel = Engine_Api::_()->user()->getViewer()->level_id;

        $this->addElement('Text', 'cust_name', array(
            'label' => 'Customer\'s Name',
            'allowEmpty' => false,
            'required' => true,
            'maxlength' => '63',

            'filters' => array(
                new Engine_Filter_Censor(),
                'StripTags',
                new Engine_Filter_StringLength(array('max' => '63'))
            ),
            'autofocus' => 'autofocus',
        ));

        $this->addElement('Text', 'cust_contact', array(
            'label' => 'Customer\'s Contact Number',
            'allowEmpty' => false,
            'required' => true,
            'maxlength' => '10',
            //'onchanged'=> 'checkNumber(this.value)',
            'autofocus' => 'autofocus',
        ));

        $this->addElement('Text', 'cust_address', array(
            'label' => 'Customer\'s address',
            'allowEmpty' => false,
            'required' => true,
            'maxlength' => '63',
            'filters' => array(
                new Engine_Filter_Censor(),
                'StripTags',
                new Engine_Filter_StringLength(array('max' => '63'))
            ),
            'autofocus' => 'autofocus',
        ));

        $this->addElement('Text', 'cust_email', array(
            'label' => 'Customer\'s Email',
            'allowEmpty' => false,
            'required' => true,
            'inputtype' => 'email',
            'maxlength' => '32',
            //'onchanged'=> 'checkEmail(this.value)',
            'autofocus' => 'autofocus',
        ));

        $this->addElement('Select', 'product_id1', array(
            'label' => 'Add Products',
            'id' => 'addPro',
            'multiple' => 'true',
            'RegisterInArrayValidator' => false,
                'allowEmpty' => true,
                'required' => false,
            // 'style' => 'display:none',
        ));

       


        $this->addElement('Select', 'product_id', array(
            'label' => 'Delete Products',
            'id' => 'pro',
            'multiple' => 'true',
            'RegisterInArrayValidator' => false,
                'allowEmpty' => true,
                'required' => false,
            // 'style' => 'display:none',
        ));



       


        $this->addElement('Select', 'region', array(
            'id' => 'region',
            //'decorator'=>'Select the region',
            'required' => true,
            'label' => 'Region',
            'multiOptions' => array(
                '0'=> 'Haryana',
                '1'=> 'Out Of Haryana'
            ),
        ));

        $this->addElement('Text', 'discount', array(
            'label' => 'Discount % ',
            'allowEmpty' => true,
            'maxlength' => '3',
            //'onchanged'=> 'checkEmail(this.value)',
            'autofocus' => 'autofocus',
        ));

        $this->addElement('Select', 'status', array(
            'id' => 'status',
            'required' => true,
            //'decorator'=>'Select the region',
            'label' => 'Status',
            'multiOptions' => array(
                '0'=> 'Pending',
                '1'=> 'Paid'
            ),
        ));

        
        // Element: submit
        $this->addElement('Button', 'submit', array(
            'label' => 'Edit',
            'type' => 'submit',
        ));
    }

    
}
